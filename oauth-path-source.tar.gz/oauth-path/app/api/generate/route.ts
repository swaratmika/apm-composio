import { runAgent, type AgentEvent } from "@/lib/agent";
import { getLibraryGuides } from "@/lib/guides";
import { saveGuide } from "@/lib/store";

export const runtime = "nodejs";
export const maxDuration = 300;

// Small in-memory limiter to protect the API key on a public demo.
// Per-instance only; use a shared store for real protection.
const WINDOW_MS = 60 * 60 * 1000;
const MAX_PER_WINDOW = Number(process.env.GENERATE_LIMIT_PER_HOUR || 6);
const hits = new Map<string, number[]>();

function limited(ip: string): boolean {
  const now = Date.now();
  const recent = (hits.get(ip) ?? []).filter((t) => now - t < WINDOW_MS);
  if (recent.length >= MAX_PER_WINDOW) {
    hits.set(ip, recent);
    return true;
  }
  recent.push(now);
  hits.set(ip, recent);
  return false;
}

export async function POST(req: Request) {
  let query = "";
  try {
    const body = (await req.json()) as { query?: unknown };
    query = typeof body.query === "string" ? body.query.trim() : "";
  } catch {
    return Response.json({ error: "Invalid request body." }, { status: 400 });
  }
  if (query.length < 2 || query.length > 200) {
    return Response.json({ error: "Enter an app name or website (2-200 characters)." }, { status: 400 });
  }
  if (!process.env.ANTHROPIC_API_KEY) {
    return Response.json(
      { error: "Live generation is not configured: set ANTHROPIC_API_KEY on the server." },
      { status: 503 },
    );
  }
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
  if (limited(ip)) {
    return Response.json(
      { error: `Rate limit reached (${MAX_PER_WINDOW} guides per hour). Try again later.` },
      { status: 429 },
    );
  }

  const reserved = (await getLibraryGuides()).map((g) => g.slug);
  const enc = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      let closed = false;
      const send = (e: AgentEvent | { type: "done"; slug: string }) => {
        if (closed) return;
        controller.enqueue(enc.encode(`data: ${JSON.stringify(e)}\n\n`));
      };
      try {
        const guide = await runAgent(query, send, reserved);
        await saveGuide(guide);
        send({ type: "done", slug: guide.slug });
      } catch (e) {
        send({ type: "error", message: e instanceof Error ? e.message : "Something went wrong." });
      } finally {
        closed = true;
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}

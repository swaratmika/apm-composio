import type { Metadata } from "next";
import GuideView from "@/components/GuideView";
import LocalGuide from "@/components/LocalGuide";
import { getGuide } from "@/lib/guides";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: PageProps<"/g/[slug]">): Promise<Metadata> {
  const { slug } = await params;
  const g = await getGuide(slug);
  if (!g) return { title: "Guide | OAuth Path" };
  return {
    title: `${g.name} OAuth setup: difficulty ${g.difficulty}/5 | OAuth Path`,
    description: g.verdict,
  };
}

export default async function GuidePage({ params }: PageProps<"/g/[slug]">) {
  const { slug } = await params;
  const guide = await getGuide(slug);
  if (!guide) return <LocalGuide slug={slug} />;
  return <GuideView guide={guide} />;
}

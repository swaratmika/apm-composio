import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "OAuth Path: how hard is it to ship this integration?",
  description:
    "Look up an app and get a shareable guide to registering and getting its OAuth app approved: difficulty, time, requirements, blockers, and what an agent can do for you.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en">
      <body>
        <header className="site-head no-print">
          <Link href="/" className="brand">
            OAuth Path
          </Link>
          <span className="muted small">Setup and approval guides for agent integrations</span>
        </header>
        <main className="container">{children}</main>
        <footer className="site-foot muted small no-print">
          Guides cite their sources and label what was read, tested, or is still uncertain. Not legal or compliance
          advice. Confirm in the provider&apos;s console before you plan a launch date.
        </footer>
      </body>
    </html>
  );
}

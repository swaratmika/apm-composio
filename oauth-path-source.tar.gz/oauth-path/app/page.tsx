import Link from "next/link";
import Generator from "@/components/Generator";
import { DifficultyMeter } from "@/components/Badges";
import { getLibraryGuides } from "@/lib/guides";

export const dynamic = "force-dynamic";

export default async function Home() {
  const guides = await getLibraryGuides();
  const lib = guides.map((g) => ({ slug: g.slug, name: g.name, website: g.website }));

  return (
    <>
      <section className="hero">
        <h1>Can your users connect this app, and what will it take?</h1>
        <p className="lead">
          Before an agent can act in a user&apos;s account you may have to register an OAuth app with the provider
          and get it approved. Look up an app to see how hard that is, how long it takes, what can block you, and
          which parts an agent can do for you.
        </p>
        <Generator library={lib} />
      </section>

      <section>
        <h2>Guide library</h2>
        <p className="muted small">
          Sorted from easiest to hardest. The five guides cover different kinds of gate: none, optional review,
          partner programs, and annual security audits.
        </p>
        <div className="lib-grid">
          {guides.map((g) => (
            <Link key={g.slug} href={`/g/${g.slug}`} className="card lib-card">
              <div className="path-head">
                <h3>{g.name}</h3>
                <DifficultyMeter value={g.difficulty} label={g.difficultyLabel} />
              </div>
              <p className="small">{g.verdict}</p>
              <p className="muted small">{g.category}</p>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}

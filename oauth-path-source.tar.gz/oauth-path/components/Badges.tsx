import type { Evidence, Owner } from "@/lib/types";

const EVIDENCE_LABEL: Record<Evidence, string> = {
  "official-docs": "Official docs",
  probe: "Probe",
  "third-party": "Third-party",
  uncertain: "Uncertain",
};

export function EvidenceBadge({ evidence }: { evidence: Evidence }) {
  return <span className={`badge ev-${evidence}`}>{EVIDENCE_LABEL[evidence]}</span>;
}

const OWNER_LABEL: Record<Owner, string> = {
  agent: "Agent can do",
  you: "You do",
  provider: "Provider / waiting",
};

export function OwnerBadge({ owner }: { owner: Owner }) {
  return <span className={`badge own-${owner}`}>{OWNER_LABEL[owner]}</span>;
}

export function DifficultyMeter({ value, label }: { value: number; label?: string }) {
  return (
    <span className="meter" aria-label={`Difficulty ${value} of 5${label ? `, ${label}` : ""}`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <span key={i} className={`dot ${i <= value ? `on lvl-${value}` : ""}`} />
      ))}
      {label ? <span className="meter-label">{label}</span> : null}
    </span>
  );
}

export function Cites({ idx }: { idx?: number[] }) {
  if (!idx || idx.length === 0) return null;
  return (
    <sup className="cites">
      {idx.map((i) => (
        <a key={i} href={`#src-${i + 1}`}>
          [{i + 1}]
        </a>
      ))}
    </sup>
  );
}

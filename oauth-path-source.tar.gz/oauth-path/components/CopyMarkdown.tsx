"use client";

import { useState } from "react";
import type { Guide } from "@/lib/types";
import { guideToMarkdown } from "@/lib/markdown";

export default function CopyMarkdown({ guide }: { guide: Guide }) {
  const [state, setState] = useState<"idle" | "copied" | "failed">("idle");

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setState("copied");
    } catch {
      setState("failed");
    }
    setTimeout(() => setState("idle"), 1800);
  }

  async function copyMd() {
    try {
      await navigator.clipboard.writeText(guideToMarkdown(guide));
      setState("copied");
    } catch {
      setState("failed");
    }
    setTimeout(() => setState("idle"), 1800);
  }

  function download() {
    const blob = new Blob([JSON.stringify(guide, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${guide.slug}-oauth-guide.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  return (
    <div className="btn-row">
      <button type="button" onClick={copyLink}>
        Copy link
      </button>
      <button type="button" onClick={copyMd}>
        Copy as Markdown
      </button>
      <button type="button" onClick={download}>
        Download JSON
      </button>
      <button type="button" onClick={() => window.print()}>
        Print / save PDF
      </button>
      <span className="muted small" role="status">
        {state === "copied" ? "Copied" : state === "failed" ? "Copy failed" : ""}
      </span>
    </div>
  );
}

"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useRef, useState } from "react";
import type { Guide } from "@/lib/types";

type Lib = { slug: string; name: string; website: string };
type LogLine = { kind: "status" | "search" | "fetch" | "probe" | "error"; text: string };

export default function Generator({ library }: { library: Lib[] }) {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [running, setRunning] = useState(false);
  const [log, setLog] = useState<LogLine[]>([]);
  const [error, setError] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const matches = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (q.length < 2) return [];
    return library.filter(
      (l) => l.name.toLowerCase().includes(q) || l.slug.includes(q) || l.website.toLowerCase().includes(q),
    );
  }, [query, library]);

  async function run(e: React.FormEvent) {
    e.preventDefault();
    const q = query.trim();
    if (q.length < 2 || running) return;
    setRunning(true);
    setError(null);
    setLog([]);
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ query: q }),
        signal: ctrl.signal,
      });
      if (!res.ok || !res.body) {
        const j = (await res.json().catch(() => null)) as { error?: string } | null;
        throw new Error(j?.error || `Request failed (${res.status})`);
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      let finished = false;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let idx: number;
        while ((idx = buf.indexOf("\n\n")) !== -1) {
          const chunk = buf.slice(0, idx);
          buf = buf.slice(idx + 2);
          if (!chunk.startsWith("data: ")) continue;
          const ev = JSON.parse(chunk.slice(6)) as
            | { type: "status"; text: string }
            | { type: "search"; query: string }
            | { type: "fetch"; url: string }
            | { type: "probe"; url: string; summary: string }
            | { type: "guide"; guide: Guide }
            | { type: "done"; slug: string }
            | { type: "error"; message: string };
          if (ev.type === "status") setLog((l) => [...l, { kind: "status", text: ev.text }]);
          else if (ev.type === "search") setLog((l) => [...l, { kind: "search", text: `Searching: ${ev.query}` }]);
          else if (ev.type === "fetch") setLog((l) => [...l, { kind: "fetch", text: `Reading: ${ev.url}` }]);
          else if (ev.type === "probe")
            setLog((l) => [...l, { kind: "probe", text: `Probe ${ev.url}: ${ev.summary}` }]);
          else if (ev.type === "guide") {
            // Keep a browser copy in case the server's storage is ephemeral.
            try {
              localStorage.setItem(`guide:${ev.guide.slug}`, JSON.stringify(ev.guide));
            } catch {}
          } else if (ev.type === "error") throw new Error(ev.message);
          else if (ev.type === "done") {
            finished = true;
            router.push(`/g/${ev.slug}`);
          }
        }
      }
      if (!finished) throw new Error("The connection ended before the guide was ready. Please try again.");
    } catch (err) {
      if ((err as Error).name !== "AbortError") setError((err as Error).message);
      setRunning(false);
    }
  }

  function cancel() {
    abortRef.current?.abort();
    setRunning(false);
    setLog((l) => [...l, { kind: "status", text: "Cancelled" }]);
  }

  return (
    <div className="generator">
      <form onSubmit={run} className="gen-form">
        <label htmlFor="q" className="sr-only">
          App name or website
        </label>
        <input
          id="q"
          type="text"
          placeholder="Type an app name or website, e.g. Notion or hubspot.com"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          disabled={running}
          maxLength={200}
          autoComplete="off"
        />
        <button type="submit" className="primary" disabled={running || query.trim().length < 2}>
          {running ? "Researching..." : "Generate guide"}
        </button>
        {running && (
          <button type="button" onClick={cancel}>
            Cancel
          </button>
        )}
      </form>

      {matches.length > 0 && !running && (
        <p className="small">
          Already in the library:{" "}
          {matches.map((m, i) => (
            <span key={m.slug}>
              {i > 0 && ", "}
              <Link href={`/g/${m.slug}`}>{m.name}</Link>
            </span>
          ))}
          . Or generate a fresh one live.
        </p>
      )}

      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}

      {log.length > 0 && (
        <ol className="log" aria-live="polite">
          {log.map((l, i) => (
            <li key={i} className={`log-${l.kind}`}>
              {l.text}
            </li>
          ))}
        </ol>
      )}
      {running && (
        <p className="muted small">
          The agent searches official docs, reads them, and may send an unauthenticated test request. This usually
          takes one to three minutes.
        </p>
      )}
    </div>
  );
}

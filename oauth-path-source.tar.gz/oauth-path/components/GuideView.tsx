import type { Guide } from "@/lib/types";
import { Cites, DifficultyMeter, EvidenceBadge, OwnerBadge } from "./Badges";
import CopyMarkdown from "./CopyMarkdown";

const REQUIRED_LABEL = { yes: "Required", no: "Not required", depends: "Depends", unknown: "Unknown" } as const;

export default function GuideView({ guide: g, note }: { guide: Guide; note?: string }) {
  return (
    <article className="guide">
      <header className="guide-head">
        <div className="guide-title-row">
          <h1>{g.name}</h1>
          <DifficultyMeter value={g.difficulty} label={g.difficultyLabel} />
        </div>
        <p className="verdict">{g.verdict}</p>
        <p className="muted small">
          {g.category} · Checked {g.meta.checkedOn} ·{" "}
          {g.meta.generatedBy === "live-agent" ? "Generated live by an agent" : "Library guide"} ·{" "}
          <a href={g.website} target="_blank" rel="noreferrer">
            {g.website.replace(/^https?:\/\//, "")}
          </a>
        </p>
        {note ? <p className="note">{note}</p> : null}
        <div className="legend" aria-label="Evidence legend">
          <EvidenceBadge evidence="official-docs" /> read on an official page
          <EvidenceBadge evidence="probe" /> observed by a test request
          <EvidenceBadge evidence="third-party" /> only a non-official source says so
          <EvidenceBadge evidence="uncertain" /> estimate or unverified
        </div>
        <div className="actions no-print">
          <CopyMarkdown guide={g} />
        </div>
      </header>

      <section>
        <h2>Time and effort</h2>
        <div className="grid2">
          <div className="card">
            <h3>Your hands-on work</h3>
            <p>{g.timeline.handsOn}</p>
          </div>
          <div className="card">
            <h3>Waiting on the provider</h3>
            <p>{g.timeline.waiting}</p>
          </div>
        </div>
        <p className="small">
          {g.timeline.note} <EvidenceBadge evidence={g.timeline.evidence} />
          <Cites idx={g.timeline.sources} />
        </p>
      </section>

      <section>
        <h2>Pick your path</h2>
        <p className="muted small">Difficulty depends on what your agent needs to do. Choose the row that matches.</p>
        <div className="paths">
          {g.paths.map((p) => (
            <div className="card" key={p.name}>
              <div className="path-head">
                <h3>{p.name}</h3>
                <DifficultyMeter value={p.difficulty} />
              </div>
              <p>{p.whenYouNeedIt}</p>
              <dl className="kv">
                <dt>Hands-on</dt>
                <dd>{p.handsOn}</dd>
                <dt>Waiting</dt>
                <dd>{p.waiting}</dd>
              </dl>
              <EvidenceBadge evidence={p.evidence} />
              <Cites idx={p.sources} />
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2>Approval gates</h2>
        <ul className="rows">
          {g.gates.map((x) => (
            <li key={x.name}>
              <div className="row-head">
                <strong>{x.name}</strong>
                <span className={`badge req-${x.required}`}>{REQUIRED_LABEL[x.required]}</span>
                <EvidenceBadge evidence={x.evidence} />
              </div>
              <p>
                {x.detail}
                <Cites idx={x.sources} />
              </p>
            </li>
          ))}
        </ul>
      </section>

      <section>
        <h2>Steps: who does what</h2>
        <ol className="steps">
          {g.steps.map((s, i) => (
            <li key={i}>
              <div className="row-head">
                <strong>{s.title}</strong>
                <OwnerBadge owner={s.owner} />
                <span className="badge effort">{s.effort}</span>
                <EvidenceBadge evidence={s.evidence} />
              </div>
              <p>
                {s.detail}
                <Cites idx={s.sources} />
              </p>
            </li>
          ))}
        </ol>
      </section>

      <section className="grid2">
        <div>
          <h2>Requirements</h2>
          <ul className="claims">
            {g.requirements.map((c, i) => (
              <li key={i}>
                {c.text}
                <Cites idx={c.sources} /> <EvidenceBadge evidence={c.evidence} />
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2>Nuances that can bite</h2>
          <ul className="claims">
            {g.nuances.map((c, i) => (
              <li key={i}>
                {c.text}
                <Cites idx={c.sources} /> <EvidenceBadge evidence={c.evidence} />
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section>
        <h2>If you get stuck</h2>
        <ul className="rows">
          {g.blockers.map((b, i) => (
            <li key={i}>
              <div className="row-head">
                <strong>{b.symptom}</strong>
                <OwnerBadge owner={b.owner} />
                <EvidenceBadge evidence={b.evidence} />
              </div>
              <p>
                <span className="muted">Likely cause:</span> {b.cause}
              </p>
              <p>
                <span className="muted">What to do:</span> {b.fix}
                <Cites idx={b.sources} />
              </p>
            </li>
          ))}
        </ul>
      </section>

      <section className="grid2">
        <div className="card agent">
          <h3>What an agent can do for you</h3>
          <ul>
            {g.agentCan.map((a, i) => (
              <li key={i}>{a}</li>
            ))}
          </ul>
        </div>
        <div className="card human">
          <h3>Where you take over</h3>
          <ul>
            {g.youMustDo.map((a, i) => (
              <li key={i}>{a}</li>
            ))}
          </ul>
        </div>
      </section>

      <section>
        <h2>What was tested, and what is still unknown</h2>
        <ul className="rows">
          {g.tested.map((t, i) => (
            <li key={i}>
              <div className="row-head">
                <strong>{t.what}</strong>
                <span className={`badge test-${t.status}`}>{t.status.replace("-", " ")}</span>
                <span className="muted small">{t.date}</span>
              </div>
              <p>{t.result}</p>
            </li>
          ))}
        </ul>
        <h3>Could not verify</h3>
        <ul className="claims">
          {g.uncertain.map((u, i) => (
            <li key={i}>{u}</li>
          ))}
        </ul>
        {g.corrections.length > 0 && (
          <>
            <h3>Conflicts and corrections</h3>
            <ul className="claims">
              {g.corrections.map((u, i) => (
                <li key={i}>{u}</li>
              ))}
            </ul>
          </>
        )}
      </section>

      <section>
        <h2>Sources</h2>
        <ol className="sources">
          {g.sources.map((s, i) => (
            <li key={i} id={`src-${i + 1}`}>
              <a href={s.url} target="_blank" rel="noreferrer">
                {s.title}
              </a>{" "}
              <span className={`badge ${s.kind === "official" ? "ev-official-docs" : "ev-third-party"}`}>
                {s.kind}
              </span>
            </li>
          ))}
        </ol>
      </section>
    </article>
  );
}

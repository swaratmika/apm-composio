"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import type { Guide } from "@/lib/types";
import GuideView from "./GuideView";

// Fallback for live guides whose server copy is gone (ephemeral serverless storage).
export default function LocalGuide({ slug }: { slug: string }) {
  const [guide, setGuide] = useState<Guide | null | undefined>(undefined);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(`guide:${slug}`);
      setGuide(raw ? (JSON.parse(raw) as Guide) : null);
    } catch {
      setGuide(null);
    }
  }, [slug]);

  if (guide === undefined) return <p className="muted">Loading...</p>;
  if (guide === null) {
    return (
      <div className="card">
        <h1>Guide not found</h1>
        <p>
          This guide is not in the library and is no longer stored on the server. Live guides are kept only
          temporarily. Generate it again from the home page.
        </p>
        <Link href="/">Back to the library</Link>
      </div>
    );
  }
  return (
    <GuideView
      guide={guide}
      note="This copy is stored only in your browser because the server no longer has it. Use Copy as Markdown or Download JSON to share it durably."
    />
  );
}

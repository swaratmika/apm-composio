import fs from "node:fs/promises";
import path from "node:path";
import type { Guide, TestedItem } from "./types";
import { isValidSlug, loadGeneratedGuide } from "./store";

const GUIDE_DIR = path.join(process.cwd(), "data", "guides");
const PROBE_DIR = path.join(process.cwd(), "data", "probes");

async function readProbes(slug: string): Promise<TestedItem[]> {
  try {
    const raw = await fs.readFile(path.join(PROBE_DIR, `${slug}.json`), "utf8");
    return JSON.parse(raw) as TestedItem[];
  } catch {
    return [];
  }
}

async function readLibraryGuide(slug: string): Promise<Guide | null> {
  if (!isValidSlug(slug)) return null;
  try {
    const raw = await fs.readFile(path.join(GUIDE_DIR, `${slug}.json`), "utf8");
    const guide = JSON.parse(raw) as Guide;
    // If `npm run probe` has recorded real results, they replace the "not-run" placeholder.
    const probes = await readProbes(slug);
    if (probes.length > 0) {
      guide.tested = [...guide.tested.filter((t) => t.status !== "not-run"), ...probes];
    }
    return guide;
  } catch {
    return null;
  }
}

export async function getLibraryGuides(): Promise<Guide[]> {
  const files = (await fs.readdir(GUIDE_DIR)).filter((f) => f.endsWith(".json"));
  const guides = await Promise.all(files.map((f) => readLibraryGuide(f.replace(/\.json$/, ""))));
  return guides
    .filter((g): g is Guide => g !== null)
    .sort((a, b) => a.difficulty - b.difficulty || a.name.localeCompare(b.name));
}

export async function getGuide(slug: string): Promise<Guide | null> {
  return (await readLibraryGuide(slug)) ?? (await loadGeneratedGuide(slug));
}

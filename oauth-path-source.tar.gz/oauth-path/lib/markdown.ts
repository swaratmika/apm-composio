import type { Guide, Evidence } from "./types";

const EV: Record<Evidence, string> = {
  "official-docs": "official docs",
  probe: "probe",
  "third-party": "third-party",
  uncertain: "uncertain",
};

const cite = (g: Guide, idx?: number[]) =>
  idx && idx.length ? " [" + idx.map((i) => i + 1).join(", ") + "]" : "";

/** Plain-Markdown export so a guide can be pasted into a README, ticket or chat. */
export function guideToMarkdown(g: Guide): string {
  const out: string[] = [];
  out.push(`# ${g.name}: OAuth app setup`);
  out.push(`**Difficulty ${g.difficulty}/5 (${g.difficultyLabel}).** ${g.verdict}`);
  out.push(`_Checked ${g.meta.checkedOn} (${g.meta.generatedBy}). Evidence labels: official docs, probe, third-party, uncertain._`);
  out.push(`## Time and effort`);
  out.push(`- Hands-on: ${g.timeline.handsOn}`);
  out.push(`- Waiting: ${g.timeline.waiting}`);
  out.push(`- Note: ${g.timeline.note} _(${EV[g.timeline.evidence]})_${cite(g, g.timeline.sources)}`);
  out.push(`## Paths`);
  for (const p of g.paths) {
    out.push(
      `- **${p.name}** (difficulty ${p.difficulty}/5): ${p.whenYouNeedIt} Hands-on: ${p.handsOn}. Waiting: ${p.waiting}. _(${EV[p.evidence]})_${cite(g, p.sources)}`,
    );
  }
  out.push(`## Approval gates`);
  for (const x of g.gates) {
    out.push(`- **${x.name}** (required: ${x.required}): ${x.detail} _(${EV[x.evidence]})_${cite(g, x.sources)}`);
  }
  out.push(`## Steps`);
  g.steps.forEach((s, i) => {
    out.push(
      `${i + 1}. **${s.title}** [${s.owner}, ${s.effort}]: ${s.detail} _(${EV[s.evidence]})_${cite(g, s.sources)}`,
    );
  });
  out.push(`## Requirements`);
  for (const c of g.requirements) out.push(`- ${c.text} _(${EV[c.evidence]})_${cite(g, c.sources)}`);
  out.push(`## Nuances`);
  for (const c of g.nuances) out.push(`- ${c.text} _(${EV[c.evidence]})_${cite(g, c.sources)}`);
  out.push(`## If you get stuck`);
  for (const b of g.blockers) {
    out.push(`- **${b.symptom}** Cause: ${b.cause} Fix: ${b.fix} [${b.owner}] _(${EV[b.evidence]})_${cite(g, b.sources)}`);
  }
  out.push(`## What an agent can do`);
  for (const a of g.agentCan) out.push(`- ${a}`);
  out.push(`## What you must do`);
  for (const a of g.youMustDo) out.push(`- ${a}`);
  out.push(`## What was tested`);
  for (const t of g.tested) out.push(`- ${t.what}: ${t.status}. ${t.result}`);
  out.push(`## Still uncertain`);
  for (const u of g.uncertain) out.push(`- ${u}`);
  if (g.corrections.length) {
    out.push(`## Conflicts and corrections`);
    for (const c of g.corrections) out.push(`- ${c}`);
  }
  out.push(`## Sources`);
  g.sources.forEach((s, i) => out.push(`${i + 1}. [${s.title}](${s.url}) (${s.kind})`));
  return out.join("\n\n");
}

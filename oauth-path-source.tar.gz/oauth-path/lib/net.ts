import dns from "node:dns/promises";
import net from "node:net";

// The live agent fetches URLs chosen by a language model after reading web
// pages, so every outbound request goes through these guards: https only,
// public addresses only, bounded size, bounded time, bounded redirects.

function isPrivateIp(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split(".").map(Number);
    return (
      a === 0 ||
      a === 10 ||
      a === 127 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      a >= 224
    );
  }
  const l = ip.toLowerCase();
  return (
    l === "::" ||
    l === "::1" ||
    l.startsWith("fc") ||
    l.startsWith("fd") ||
    l.startsWith("fe80") ||
    l.startsWith("::ffff:")
  );
}

export async function assertPublicHttps(raw: string): Promise<URL> {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new Error("Invalid URL");
  }
  if (url.protocol !== "https:") throw new Error("Only https URLs are allowed");
  if (url.username || url.password) throw new Error("URLs with credentials are not allowed");
  const host = url.hostname;
  if (host === "localhost" || host.endsWith(".local") || host.endsWith(".internal")) {
    throw new Error("Host not allowed");
  }
  if (net.isIP(host)) {
    if (isPrivateIp(host)) throw new Error("Address not allowed");
    return url;
  }
  const addrs = await dns.lookup(host, { all: true });
  if (addrs.length === 0 || addrs.some((a) => isPrivateIp(a.address))) {
    throw new Error("Host resolves to a non-public address");
  }
  return url;
}

export interface SafeFetchResult {
  status: number;
  finalUrl: string;
  contentType: string;
  location?: string;
  text: string;
  truncated: boolean;
}

export async function safeFetch(
  rawUrl: string,
  opts: { followRedirects: boolean; maxBytes?: number; timeoutMs?: number } = {
    followRedirects: true,
  },
): Promise<SafeFetchResult> {
  const maxBytes = opts.maxBytes ?? 400_000;
  const timeoutMs = opts.timeoutMs ?? 12_000;
  let current = rawUrl;
  for (let hop = 0; hop < 4; hop++) {
    const url = await assertPublicHttps(current);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(url, {
        redirect: "manual",
        signal: ctrl.signal,
        headers: {
          "user-agent": "oauth-path-research-bot/0.1 (OAuth setup guide generator)",
          accept: "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.5",
        },
      });
      const location = res.headers.get("location") ?? undefined;
      if (res.status >= 300 && res.status < 400 && location && opts.followRedirects) {
        current = new URL(location, url).toString();
        continue;
      }
      const reader = res.body?.getReader();
      const chunks: Uint8Array[] = [];
      let size = 0;
      let truncated = false;
      if (reader) {
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          size += value.length;
          if (size > maxBytes) {
            truncated = true;
            chunks.push(value.slice(0, value.length - (size - maxBytes)));
            await reader.cancel();
            break;
          }
          chunks.push(value);
        }
      }
      const text = Buffer.concat(chunks).toString("utf8");
      return {
        status: res.status,
        finalUrl: url.toString(),
        contentType: res.headers.get("content-type") ?? "",
        location,
        text,
        truncated,
      };
    } finally {
      clearTimeout(timer);
    }
  }
  throw new Error("Too many redirects");
}

export function htmlToText(html: string): string {
  const title = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1]?.trim();
  const body = html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ")
    .replace(/<(br|\/p|\/div|\/li|\/h[1-6]|\/tr)\s*\/?>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/[ \t]+/g, " ")
    .replace(/\n\s*\n+/g, "\n")
    .trim();
  return (title ? `TITLE: ${title}\n` : "") + body;
}

import { safeFetch, htmlToText } from "./net";

export interface ProbeResult {
  url: string;
  ok: boolean;
  status?: number;
  location?: string;
  contentType?: string;
  snippet?: string;
  error?: string;
  at: string;
}

/**
 * Unauthenticated probe of an OAuth authorize endpoint using a dummy client id.
 * It never signs in and never sends real credentials. What it can tell us is
 * limited: whether the endpoint exists and how the provider rejects an unknown
 * client (error page text, redirect target). It cannot tell us whether approval
 * will be granted.
 */
export async function probeEndpoint(url: string): Promise<ProbeResult> {
  const at = new Date().toISOString();
  try {
    const r = await safeFetch(url, { followRedirects: false, maxBytes: 60_000, timeoutMs: 10_000 });
    const isHtml = r.contentType.includes("html");
    const raw = isHtml ? htmlToText(r.text) : r.text;
    return {
      url,
      ok: true,
      status: r.status,
      location: r.location ? redactLocation(r.location) : undefined,
      contentType: r.contentType,
      snippet: raw.replace(/\s+/g, " ").slice(0, 280),
      at,
    };
  } catch (e) {
    return { url, ok: false, error: e instanceof Error ? e.message : String(e), at };
  }
}

function redactLocation(loc: string): string {
  try {
    const u = new URL(loc, "https://placeholder.invalid");
    const host = u.host === "placeholder.invalid" ? "" : u.host;
    return `${host}${u.pathname}${u.search ? "?" + [...u.searchParams.keys()].join("&") : ""}`;
  } catch {
    return loc.slice(0, 120);
  }
}

export function describeProbe(p: ProbeResult): string {
  if (!p.ok) return `Probe failed: ${p.error}`;
  const parts = [`HTTP ${p.status}`];
  if (p.location) parts.push(`redirect to ${p.location}`);
  if (p.snippet) parts.push(`response text: "${p.snippet}"`);
  return parts.join("; ");
}

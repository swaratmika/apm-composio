// Authorize endpoints probed with a dummy client id. No credentials, no sign-in.
export const PROBE_TARGETS: { slug: string; what: string; url: string }[] = [
  {
    slug: "github",
    what: "GitHub authorize endpoint with a dummy client ID",
    url: "https://github.com/login/oauth/authorize?client_id=dummyclientid123&scope=read:user",
  },
  {
    slug: "slack",
    what: "Slack authorize endpoint with a dummy client ID",
    url: "https://slack.com/oauth/v2/authorize?client_id=1234.5678&scope=chat:write",
  },
  {
    slug: "google-gmail",
    what: "Google authorize endpoint with a dummy client ID and a Gmail read scope",
    url: "https://accounts.google.com/o/oauth2/v2/auth?client_id=dummy.apps.googleusercontent.com&redirect_uri=https://example.com/cb&response_type=code&scope=https://www.googleapis.com/auth/gmail.readonly",
  },
  {
    slug: "linkedin",
    what: "LinkedIn authorization endpoint with a dummy client ID",
    url: "https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id=dummyclientid&redirect_uri=https://example.com/cb&scope=openid",
  },
  {
    slug: "shopify",
    what: "Shopify store authorize endpoint (nonexistent store) with a dummy client ID",
    url: "https://oauth-path-nonexistent-store.myshopify.com/admin/oauth/authorize?client_id=dummy&scope=read_products&redirect_uri=https://example.com/cb",
  },
];

// JSON Schema for the `submit_guide` tool the live agent must call.
// The server fills in slug, difficultyLabel, tested and meta itself, so the
// model cannot claim test results it did not obtain.

const evidence = {
  type: "string",
  enum: ["official-docs", "probe", "third-party", "uncertain"],
  description:
    "official-docs: stated on an official provider page you read. probe: directly shown by a probe_oauth result. third-party: only a non-official source says so. uncertain: estimate, inference, or not stated anywhere you read.",
};
const sources = {
  type: "array",
  items: { type: "integer", minimum: 0 },
  description: "Indexes into the top-level `sources` array that support this item.",
};
const owner = {
  type: "string",
  enum: ["agent", "you", "provider"],
  description:
    "agent: an AI agent can do it for the developer. you: the developer must do it (needs their identity, account, money or legal responsibility). provider: waiting on the provider.",
};
const str = { type: "string" };
const strArray = { type: "array", items: str };

export const guideInputSchema = {
  type: "object",
  required: [
    "name",
    "website",
    "category",
    "difficulty",
    "verdict",
    "timeline",
    "paths",
    "gates",
    "requirements",
    "nuances",
    "steps",
    "blockers",
    "agentCan",
    "youMustDo",
    "uncertain",
    "corrections",
    "sources",
  ],
  properties: {
    name: { type: "string", description: "Product name, e.g. 'Notion'." },
    website: { type: "string", description: "Official website URL." },
    category: { type: "string" },
    difficulty: {
      type: "integer",
      minimum: 1,
      maximum: 5,
      description:
        "Overall difficulty for the path most agent builders need. 1 self-serve in minutes with no review; 2 self-serve but needs real prep or light verification; 3 documented review, days to weeks; 4 gated approval or partner program, or multi-week review; 5 external audits, fees, or closed access.",
    },
    verdict: {
      type: "string",
      description: "Two sentences max: how hard is it, and what is the main obstacle.",
    },
    timeline: {
      type: "object",
      required: ["handsOn", "waiting", "note", "evidence"],
      properties: { handsOn: str, waiting: str, note: str, evidence, sources },
    },
    paths: {
      type: "array",
      description:
        "Distinct routes with different difficulty, e.g. internal vs public distribution, or scope tiers. At least 1.",
      items: {
        type: "object",
        required: ["name", "whenYouNeedIt", "difficulty", "handsOn", "waiting", "evidence"],
        properties: {
          name: str,
          whenYouNeedIt: str,
          difficulty: { type: "integer", minimum: 1, maximum: 5 },
          handsOn: str,
          waiting: str,
          evidence,
          sources,
        },
      },
    },
    gates: {
      type: "array",
      description: "Approval, verification, review, payment or eligibility gates.",
      items: {
        type: "object",
        required: ["name", "required", "detail", "evidence"],
        properties: {
          name: str,
          required: { type: "string", enum: ["yes", "no", "depends", "unknown"] },
          detail: str,
          evidence,
          sources,
        },
      },
    },
    requirements: {
      type: "array",
      items: {
        type: "object",
        required: ["text", "evidence"],
        properties: { text: str, evidence, sources },
      },
    },
    nuances: {
      type: "array",
      items: {
        type: "object",
        required: ["text", "evidence"],
        properties: { text: str, evidence, sources },
      },
    },
    steps: {
      type: "array",
      description: "Ordered steps, usually 4 to 7.",
      items: {
        type: "object",
        required: ["title", "detail", "owner", "effort", "evidence"],
        properties: { title: str, detail: str, owner, effort: str, evidence, sources },
      },
    },
    blockers: {
      type: "array",
      items: {
        type: "object",
        required: ["symptom", "cause", "fix", "owner", "evidence"],
        properties: { symptom: str, cause: str, fix: str, owner, evidence, sources },
      },
    },
    agentCan: { ...strArray, description: "What an AI agent can do for the developer." },
    youMustDo: { ...strArray, description: "What only the developer can do." },
    uncertain: { ...strArray, description: "What you could not verify." },
    corrections: {
      ...strArray,
      description:
        "Places where sources disagreed or a third party contradicted an official page. Empty if none.",
    },
    sources: {
      type: "array",
      description: "Every page you relied on. Only pages you actually read or saw in search results.",
      items: {
        type: "object",
        required: ["title", "url", "kind"],
        properties: {
          title: str,
          url: str,
          kind: { type: "string", enum: ["official", "third-party"] },
        },
      },
    },
  },
} as const;

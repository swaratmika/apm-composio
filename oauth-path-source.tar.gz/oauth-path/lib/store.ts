import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import type { Guide } from "./types";

// Live-generated guides are persisted to disk so they have a shareable URL.
// On serverless hosts this directory is ephemeral (see README, Limitations);
// swap these two functions for KV/Blob storage to make links durable.
const DIR = process.env.GUIDE_STORE_DIR || path.join(os.tmpdir(), "oauth-path-guides");
const SLUG_RE = /^[a-z0-9][a-z0-9-]{0,59}$/;

export function isValidSlug(slug: string): boolean {
  return SLUG_RE.test(slug);
}

export async function saveGuide(guide: Guide): Promise<void> {
  if (!isValidSlug(guide.slug)) throw new Error("Invalid slug");
  await fs.mkdir(DIR, { recursive: true });
  await fs.writeFile(path.join(DIR, `${guide.slug}.json`), JSON.stringify(guide, null, 2), "utf8");
}

export async function loadGeneratedGuide(slug: string): Promise<Guide | null> {
  if (!isValidSlug(slug)) return null;
  try {
    const raw = await fs.readFile(path.join(DIR, `${slug}.json`), "utf8");
    return JSON.parse(raw) as Guide;
  } catch {
    return null;
  }
}

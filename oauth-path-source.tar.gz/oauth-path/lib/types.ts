// Shared data model for an OAuth-app setup guide.
// Every factual statement carries an `evidence` label so readers can tell
// what was read in official docs, what was observed by a probe, what only a
// third party claims, and what is still unknown.

export type Evidence = "official-docs" | "probe" | "third-party" | "uncertain";
export type Owner = "agent" | "you" | "provider";

export interface Source {
  title: string;
  url: string;
  kind: "official" | "third-party";
}

export interface Claim {
  text: string;
  evidence: Evidence;
  /** indexes into Guide.sources */
  sources?: number[];
}

export interface Gate {
  name: string;
  required: "yes" | "no" | "depends" | "unknown";
  detail: string;
  evidence: Evidence;
  sources?: number[];
}

export interface Step {
  title: string;
  detail: string;
  owner: Owner;
  /** human-readable effort, e.g. "5 min" or "1-3 days" */
  effort: string;
  evidence: Evidence;
  sources?: number[];
}

export interface Blocker {
  symptom: string;
  cause: string;
  fix: string;
  owner: Owner;
  evidence: Evidence;
  sources?: number[];
}

/** Difficulty depends on what the developer needs, so a guide has several paths. */
export interface Path {
  name: string;
  whenYouNeedIt: string;
  difficulty: 1 | 2 | 3 | 4 | 5;
  handsOn: string;
  waiting: string;
  evidence: Evidence;
  sources?: number[];
}

export interface TestedItem {
  what: string;
  result: string;
  status: "passed" | "failed" | "not-run" | "informational";
  date: string;
}

export interface Guide {
  slug: string;
  name: string;
  website: string;
  category: string;
  /** 1 = self-serve in minutes ... 5 = weeks of external review and cost */
  difficulty: 1 | 2 | 3 | 4 | 5;
  difficultyLabel: string;
  verdict: string;
  timeline: {
    handsOn: string;
    waiting: string;
    note: string;
    evidence: Evidence;
    sources?: number[];
  };
  paths: Path[];
  gates: Gate[];
  requirements: Claim[];
  nuances: Claim[];
  steps: Step[];
  blockers: Blocker[];
  agentCan: string[];
  youMustDo: string[];
  tested: TestedItem[];
  uncertain: string[];
  /** Places where a third-party source disagreed with an official one, or was corrected. */
  corrections: string[];
  sources: Source[];
  meta: {
    generatedBy: "library" | "live-agent";
    checkedOn: string;
  };
}

export const DIFFICULTY_LABELS: Record<number, string> = {
  1: "Self-serve",
  2: "Easy",
  3: "Moderate",
  4: "Hard",
  5: "Very hard",
};

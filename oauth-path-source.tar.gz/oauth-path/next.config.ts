import type { NextConfig } from "next";

// cacheComponents is left off on purpose: guides are read per request (library files plus
// live-generated guides), so the classic dynamic-rendering model with `dynamic` route config fits.
const nextConfig: NextConfig = {};

export default nextConfig;

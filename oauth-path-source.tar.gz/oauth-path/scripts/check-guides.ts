// Lints the hand-written library guides with the same evidence rules the live agent is held to,
// and unit-tests the server-side integrity pass. Usage: npm run check
import fs from "node:fs";
import path from "node:path";
import { buildGuide } from "../lib/agent";
import type { Guide } from "../lib/types";

let failures = 0;
const fail = (m: string) => {
  failures++;
  console.error("FAIL " + m);
};

// 1) Library guides
const dir = path.join(process.cwd(), "data", "guides");
for (const f of fs.readdirSync(dir).filter((x) => x.endsWith(".json"))) {
  const g = JSON.parse(fs.readFileSync(path.join(dir, f), "utf8")) as Guide;
  const where = (s: string) => `${f}: ${s}`;
  const items: { label: string; evidence: string; sources?: number[] }[] = [
    { label: "timeline", ...g.timeline },
    ...g.paths.map((x) => ({ label: `path ${x.name}`, ...x })),
    ...g.gates.map((x) => ({ label: `gate ${x.name}`, ...x })),
    ...g.requirements.map((x) => ({ label: `requirement ${x.text.slice(0, 30)}`, ...x })),
    ...g.nuances.map((x) => ({ label: `nuance ${x.text.slice(0, 30)}`, ...x })),
    ...g.steps.map((x) => ({ label: `step ${x.title}`, ...x })),
    ...g.blockers.map((x) => ({ label: `blocker ${x.symptom.slice(0, 30)}`, ...x })),
  ];
  for (const it of items) {
    for (const i of it.sources ?? []) {
      if (!g.sources[i]) fail(where(`${it.label} cites missing source ${i}`));
    }
    if (it.evidence === "official-docs" && !(it.sources ?? []).some((i) => g.sources[i]?.kind === "official")) {
      fail(where(`${it.label} is labeled official-docs without an official source`));
    }
    if (it.evidence === "third-party" && !(it.sources ?? []).length) {
      fail(where(`${it.label} is labeled third-party without a source`));
    }
    if (it.evidence === "probe") fail(where(`${it.label} claims probe evidence but library probes live in data/probes`));
  }
  g.sources.forEach((s, i) => {
    if (!/^https:\/\//.test(s.url)) fail(where(`source ${i} is not https`));
  });
  const used = new Set<number>();
  for (const it of items) for (const i of it.sources ?? []) used.add(i);
  g.sources.forEach((s, i) => {
    if (!used.has(i)) console.warn(where(`note: source ${i} (${s.title}) is not cited by any claim`));
  });
  console.log(`ok ${f} (${items.length} labeled items)`);
}

// 2) Integrity pass: model-proposed labels must not survive without support.
const raw = {
  name: "Testapp",
  website: "https://example.com",
  category: "x",
  difficulty: 9,
  verdict: "v",
  timeline: { handsOn: "a", waiting: "b", note: "c", evidence: "official-docs" },
  paths: [{ name: "p", whenYouNeedIt: "w", difficulty: 0, handsOn: "h", waiting: "w", evidence: "probe" }],
  gates: [{ name: "g", required: "yes", detail: "d", evidence: "official-docs", sources: [0, 7] }],
  requirements: [{ text: "r", evidence: "official-docs", sources: [1] }],
  nuances: [{ text: "n", evidence: "third-party" }],
  steps: [
    { title: "s1", detail: "d", owner: "you", effort: "1h", evidence: "probe" },
    { title: "s2", detail: "d", owner: "agent", effort: "1h", evidence: "official-docs", sources: [0] },
    { title: "s3", detail: "d", owner: "provider", effort: "1h", evidence: "uncertain" },
  ],
  blockers: [{ symptom: "s", cause: "c", fix: "f", owner: "you", evidence: "uncertain" }],
  agentCan: ["a"],
  youMustDo: ["y"],
  uncertain: [],
  corrections: [],
  sources: [
    { title: "blog", url: "https://blog.example.com", kind: "third-party" },
    { title: "docs", url: "https://docs.example.com", kind: "official" },
  ],
};
const g = buildGuide(raw, [], new Set(["testapp"]));
const expect = (cond: boolean, msg: string) => (cond ? console.log("ok " + msg) : fail(msg));
expect(g.difficulty === 5 && g.difficultyLabel === "Very hard", "difficulty clamped to 1-5");
expect(g.paths[0].difficulty === 1, "path difficulty clamped");
expect(g.timeline.evidence === "uncertain", "official-docs with no sources is downgraded");
expect(g.gates[0].evidence === "uncertain", "official-docs citing only a third-party source is downgraded");
expect(JSON.stringify(g.gates[0].sources) === "[0]", "out-of-range citation indexes are dropped");
expect(g.requirements[0].evidence === "official-docs", "official-docs citing an official source stands");
expect(g.nuances[0].evidence === "uncertain", "third-party with no source is downgraded");
expect(g.paths[0].evidence === "uncertain", "probe claim with no successful probe is downgraded");
expect(g.steps[0].evidence === "uncertain", "probe step with no successful probe is downgraded");
expect(g.tested.length === 1 && g.tested[0].status === "not-run", "tested is built by code, not by the model");
expect(g.slug.startsWith("live-testapp-"), "slug avoids library collisions");
expect(g.uncertain.some((u) => u.includes("relabeled")), "downgrades are disclosed to the reader");

const withProbe = buildGuide(raw, [{ url: "https://x.example/auth", ok: true, status: 400, at: "now", snippet: "bad client" }], new Set());
expect(withProbe.paths[0].evidence === "probe", "probe label stands when a probe succeeded");
expect(withProbe.tested[0].status === "informational", "successful probe recorded as informational, not 'passed'");

console.log(failures === 0 ? "\nAll checks passed." : `\n${failures} check(s) failed.`);
process.exit(failures === 0 ? 0 : 1);

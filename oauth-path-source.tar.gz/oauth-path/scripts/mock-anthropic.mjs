// Scripted stand-in for the Anthropic Messages API, used to exercise the real agent loop,
// tool dispatch, validation, evidence enforcement, SSE route and storage without a live model.
// Usage: node scripts/mock-anthropic.mjs 4010
//        ANTHROPIC_BASE_URL=http://localhost:4010 ANTHROPIC_API_KEY=test npm run dev
import http from "node:http";

const port = Number(process.argv[2] || 4010);

const msg = (content, stop_reason) => ({
  id: "msg_mock",
  type: "message",
  role: "assistant",
  model: "mock",
  content,
  stop_reason,
  stop_sequence: null,
  usage: { input_tokens: 1, output_tokens: 1 },
});

const goodGuide = {
  name: "Mockapp",
  website: "https://mockapp.example",
  category: "Testing",
  difficulty: 3,
  verdict: "Mock verdict. Review is required but its duration is not stated.",
  timeline: { handsOn: "A day (estimate)", waiting: "Not stated", note: "Mock note", evidence: "official-docs" },
  paths: [
    { name: "Public", whenYouNeedIt: "Everyone", difficulty: 3, handsOn: "1 day", waiting: "unknown", evidence: "probe" },
  ],
  gates: [
    { name: "App review", required: "yes", detail: "Docs say review is required.", evidence: "official-docs", sources: [0] },
  ],
  requirements: [{ text: "Needs a privacy policy.", evidence: "official-docs", sources: [1] }],
  nuances: [{ text: "A blog says reviews take 2 weeks.", evidence: "third-party", sources: [1] }],
  steps: [
    { title: "Register", detail: "Create the app.", owner: "you", effort: "10 min", evidence: "official-docs", sources: [0] },
    { title: "Draft justification", detail: "Write scope reasons.", owner: "agent", effort: "1 hour", evidence: "uncertain" },
    { title: "Wait", detail: "Provider reviews.", owner: "provider", effort: "unknown", evidence: "uncertain" },
  ],
  blockers: [{ symptom: "Rejected", cause: "Vague scopes", fix: "Justify each scope", owner: "you", evidence: "uncertain" }],
  agentCan: ["Draft scope justifications"],
  youMustDo: ["Submit the form"],
  uncertain: ["Review duration"],
  corrections: [],
  sources: [
    { title: "Mock official docs", url: "https://docs.mockapp.example/oauth", kind: "official" },
    { title: "Mock blog", url: "https://blog.example.com/mockapp", kind: "third-party" },
  ],
};

http
  .createServer((req, res) => {
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", () => {
      if (req.method !== "POST" || !req.url?.startsWith("/v1/messages")) {
        res.writeHead(404).end();
        return;
      }
      const n = JSON.parse(body).messages.length;
      let out;
      if (n === 1) {
        out = msg(
          [
            { type: "server_tool_use", id: "srvtoolu_1", name: "web_search", input: { query: "mockapp oauth app review" } },
            { type: "tool_use", id: "tu_fetch", name: "fetch_page", input: { url: "http://169.254.169.254/latest/meta-data/" } },
            { type: "tool_use", id: "tu_probe", name: "probe_oauth", input: { url: "https://localhost/authorize?client_id=dummy" } },
          ],
          "tool_use",
        );
      } else if (n === 3) {
        // Deliberately incomplete: the server must reject it and tell the model why.
        out = msg([{ type: "tool_use", id: "tu_bad", name: "submit_guide", input: { name: "Mockapp" } }], "tool_use");
      } else {
        out = msg([{ type: "tool_use", id: "tu_good", name: "submit_guide", input: goodGuide }], "tool_use");
      }
      console.log(`[mock] request with ${n} message(s) -> ${out.content.map((b) => b.name || b.type).join(", ")}`);
      res.writeHead(200, { "content-type": "application/json" }).end(JSON.stringify(out));
    });
  })
  .listen(port, () => console.log(`mock Anthropic API on :${port}`));

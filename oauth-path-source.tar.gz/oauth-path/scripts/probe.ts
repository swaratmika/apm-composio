// Records real, unauthenticated probe results for the library apps.
// Usage: npm run probe        (needs open outbound HTTPS)
// Writes data/probes/<slug>.json, which the app merges into each guide's "tested" section.
import fs from "node:fs/promises";
import path from "node:path";
import { PROBE_TARGETS } from "../lib/probeTargets";
import { describeProbe, probeEndpoint } from "../lib/probe";
import type { TestedItem } from "../lib/types";

async function main() {
  const dir = path.join(process.cwd(), "data", "probes");
  await fs.mkdir(dir, { recursive: true });
  const date = new Date().toISOString().slice(0, 10);
  let okCount = 0;

  for (const t of PROBE_TARGETS) {
    const p = await probeEndpoint(t.url);
    const item: TestedItem = {
      what: t.what,
      result: describeProbe(p),
      status: p.ok ? "informational" : "failed",
      date,
    };
    console.log(`${t.slug}: ${item.status} - ${item.result.slice(0, 200)}`);
    if (p.ok) {
      okCount++;
      await fs.writeFile(path.join(dir, `${t.slug}.json`), JSON.stringify([item], null, 2) + "\n");
    }
  }
  console.log(`\n${okCount}/${PROBE_TARGETS.length} probes succeeded.`);
  if (okCount < PROBE_TARGETS.length) {
    console.log("Failed probes were not written, so those guides still show 'not run'.");
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
